import java.util.Random; 
import java.util.Arrays;



public class Percolation {
	double p = 0.5;
	double delta = 0.05;
	Random random = new Random();



	int[][] ground(int n, double p) {
		/*Returns an array of n arrays of integer, where each array length n
		and each integer has probability p of being a sand grain and 
		probability 1-p of being empty. Use encoding 0 = empty space, 1 = sand grain
		and 2 = water */
		int[][] g = new int[n][n];

		for(int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				int fillGround = random.nextInt(100) + 1;
				if (fillGround < p * 100) {
					g[i][j] = 1;
				} else {
					g[i][j] = 0;
				}

			}
		}

		return g;
	}

	void seep(int[][] ground, int row) {
		/* Causes water to flow from row into row + 1, modifying the array. 
		 * Performing one step of the simulation */
		if (row == -1) {
			for (int i = 0; i < ground.length; i++) {
				if (ground[0][i] == 0) {
					ground[0][i] = 2;

				}
			}
		}
		else {
			for (int i = 0; i < ground.length; i++) {
				if (ground[row][i] == 2 && ground[row + 1][i] == 0)
					ground[row+1][i] = 2;
			}
		}for (int i = 0; i < ground.length; i++) {
			int k = i;
			while (k < ground.length - 1 && ground[row + 1][k] == 2 && ground[row + 1][k + 1] == 0) {
				ground[row + 1][k + 1] = 2;
				k++;
			}k = i;
			while ( k > 0 && ground [row + 1][k] == 2 && ground[row + 1][k - 1] == 0) {
				if (ground[row + 1][k] == 2 && ground [row + 1][k - 1] == 0) {
					ground[row + 1][k - 1] = 2;
					k--;
				}

			}
		}


	}


	boolean percolate(int[][] ground) {
		//check if any slot in last row is filled with water, Returns true when it seeps to bottom array, false otherwise
		boolean bottomRow = false;
		for (int i = -1; i <= ground.length - 2; i++) {
			seep(ground, i);
		}
		for (int j = 0; j < ground.length; j++) {
			if (ground[ground.length - 1][j] == 2) {
				bottomRow = true;
			}
		}
		return bottomRow;

	}



	double findProbability(int n) {
		/*for an n x n array, determines the packing probability p that causes
		 * the array to have a 50% probability of water seeping all the way to the
		 * bottom*/
		int count = 0; 
		double p = 0.5;
		int[][] ground;
		double delta = 0.01;

		while (delta > 0.0001) {
			for (int i = 0; i < 100; i++) {
				ground = ground(n,p);
				if (percolate(ground)) {
					count = count + 1;
				}
				if (count < 50) {
					p -= delta;
					delta = delta * 0.91;
				}
				if (count > 50) {
					p += delta;
					delta = delta * 0.91;
				}

			}
		}
		return p;
	}



	public static void main(String[] args) {
		Percolation percolation = new Percolation();
		System.out.println("The packaging probability is " + percolation.findProbability(50) + " when the array length is 50");
		System.out.println("The packaging probability is " + percolation.findProbability(100) + " when the array length is 100");
		System.out.println("The packaging probability is " + percolation.findProbability(200) + " when the array length is 200");

	}
}


