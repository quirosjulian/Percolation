import static org.junit.Assert.*;

import org.junit.Test;

public class PercolationTest {
	Percolation check = new Percolation();

	@Test
	public void testGround() {
		int n = 50;
		double p = 0.5;
		double sand = 0;
		int[][] g = check.ground(n, p);
		for (int i = 0; i < g.length; i++) {
			for (int j = 0; j < g.length; j++) {
				if (g[i][j] == 1) {
					sand++;
				}
			}
		}
		sand = sand/2500;
		assertEquals(p, sand, 0.1);
		
	}

	@Test
	public void testSeep() {
		int[][] test = {{0,0,0}, {0,1,0}, {1,0,1}};
		check.seep(test, -1);
		int[][] expected = {{2,2,2}, {0, 1, 0}, {1, 0, 1}};
		assertArrayEquals(test, expected);
		
			}

	@Test
	public void testPercolate() {
		int[][] test = {{0,0,0}, {0, 0, 1}, {0,0,0}};
		assertTrue(check.percolate(test));
	}

}
